"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    IGNORED_DIRS: function() {
        return IGNORED_DIRS;
    },
    TOKEN_REGEX: function() {
        return TOKEN_REGEX;
    },
    VALID_EXTENSIONS: function() {
        return VALID_EXTENSIONS;
    },
    knownTokenImportsAndModules: function() {
        return knownTokenImportsAndModules;
    }
});
const TOKEN_REGEX = /tokens\.[a-zA-Z0-9.]+/g;
const IGNORED_DIRS = [
    'node_modules',
    'dist',
    'build',
    '.git'
];
const VALID_EXTENSIONS = [
    '.ts',
    '.tsx',
    '.js',
    '.jsx',
    '.mjs'
];
const knownTokenImportsAndModules = {
    // if we see any imports from the defaults, we assume it's a token.
    default: [
        '@fluentui/semantic-tokens'
    ],
    // begin the known token imports
    tokens: [
        '@fluentui/react-theme',
        '@fluentui/react-components',
        '@fluentui/tokens'
    ]
};

//# sourceMappingURL=types.js.map