"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    cornerCtrlLgHoverRaw: function() {
        return _moreimporttest.cornerCtrlLgHoverRaw;
    },
    importTest: function() {
        return importTest;
    }
});
const _semantictokens = require("@fluentui/semantic-tokens");
const _moreimporttest = require("./more-import-test");
const importTest = _semantictokens.ctrlLinkForegroundBrandHover;

//# sourceMappingURL=import-test.js.map