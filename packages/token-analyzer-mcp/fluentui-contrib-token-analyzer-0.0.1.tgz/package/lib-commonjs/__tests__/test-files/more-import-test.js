// test direct export from the semantic tokens package
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "cornerCtrlLgHoverRaw", {
    enumerable: true,
    get: function() {
        return _semantictokens.cornerCtrlLgHoverRaw;
    }
});
const _semantictokens = require("@fluentui/semantic-tokens");

//# sourceMappingURL=more-import-test.js.map