"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    anotherNode: function() {
        return anotherNode;
    },
    evenMoreNodes: function() {
        return evenMoreNodes;
    },
    moreNodes: function() {
        return moreNodes;
    },
    someNode: function() {
        return someNode;
    },
    template1: function() {
        return template1;
    },
    template2: function() {
        return template2;
    },
    template3: function() {
        return template3;
    },
    template4: function() {
        return template4;
    },
    template5: function() {
        return template5;
    },
    template6: function() {
        return template6;
    },
    template7: function() {
        return template7;
    },
    template8: function() {
        return template8;
    },
    template9: function() {
        return template9;
    }
});
const someNode = 'some value';
const anotherNode = 'another value';
const moreNodes = 'more values';
const evenMoreNodes = 'even more values';
const template1 = `var(--a, var(${someNode}, var(${anotherNode}))) var(${moreNodes}, var(${evenMoreNodes}))`;
const template2 = `var(--x) no-extraction var(--y, ${someNode}) var(${moreNodes}, var(--z, ${anotherNode}, ${evenMoreNodes}))`;
const template3 = `no var functions here just ${someNode} and ${anotherNode}`;
const template4 = `var(${someNode}) simple case`;
const template5 = `var(--deep, var(--deeper, var(--deepest, ${someNode}, ${anotherNode}, var(${moreNodes}))))`;
const template6 = `var(${someNode}) var(${anotherNode}) var(${moreNodes}) var(${evenMoreNodes})`;
const template7 = `var(--broken, var(${someNode}, var(${anotherNode})) var(${moreNodes})`;
const template8 = `var(--empty) var(--also-empty, ${someNode})`;
const template9 = `color: red; background: var(--bg, ${someNode}); padding: 10px; border: var(--border, ${anotherNode})`;

//# sourceMappingURL=test-templates.js.map