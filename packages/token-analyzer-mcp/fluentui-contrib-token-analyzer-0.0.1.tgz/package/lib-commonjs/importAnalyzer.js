// importAnalyzer.ts
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "analyzeImports", {
    enumerable: true,
    get: function() {
        return analyzeImports;
    }
});
const _tsmorph = require("ts-morph");
const _debugUtils = require("./debugUtils.js");
const _reexportResolver = require("./reexportResolver");
const _moduleResolver = require("./moduleResolver.js");
const _tokenUtils = require("./tokenUtils");
async function analyzeImports(sourceFile, project) {
    const importedValues = new Map();
    const filePath = sourceFile.getFilePath();
    (0, _debugUtils.log)(`Analyzing imports in ${filePath}`);
    // Get TypeScript's type checker
    const typeChecker = project.getTypeChecker();
    // Process all import declarations
    for (const importDecl of sourceFile.getImportDeclarations()){
        try {
            // Process the import declaration
            await processImportDeclaration(importDecl, sourceFile, project, importedValues, typeChecker);
        } catch (err) {
            (0, _debugUtils.log)(`Error processing import: ${importDecl.getModuleSpecifierValue()}`, err);
        }
    }
    return importedValues;
}
/**
 * Process a single import declaration
 */ async function processImportDeclaration(importDecl, sourceFile, project, importedValues, typeChecker) {
    const moduleSpecifier = importDecl.getModuleSpecifierValue();
    const containingFilePath = sourceFile.getFilePath();
    // Use our module resolver to get the imported file
    const importedFile = (0, _moduleResolver.getModuleSourceFile)(project, moduleSpecifier, containingFilePath);
    if (!importedFile) {
        (0, _debugUtils.log)(`Could not resolve module: ${moduleSpecifier}`);
        return;
    }
    const context = {
        importDecl,
        moduleSpecifier,
        importedFile,
        typeChecker,
        importedValues,
        project
    };
    // Process named imports (import { x } from 'module')
    processNamedImports(context);
    // Process default import (import x from 'module')
    processDefaultImport(context);
    processNamespaceImport(context);
}
/**
 * Process named imports using TypeScript's type checker to follow re-exports
 */ function processNamedImports(context) {
    const { importDecl, typeChecker, project } = context;
    const namedImports = importDecl.getNamedImports();
    namedImports.forEach((namedImport)=>{
        var _namedImport_getAliasNode;
        var _namedImport_getAliasNode1;
        const nameOrAliasNode = (_namedImport_getAliasNode1 = namedImport.getAliasNode()) != null ? _namedImport_getAliasNode1 : namedImport;
        const importName = namedImport.getName();
        const alias = ((_namedImport_getAliasNode = namedImport.getAliasNode()) == null ? void 0 : _namedImport_getAliasNode.getText()) || importName;
        if ((0, _tokenUtils.isKnownTokenPackage)(context.moduleSpecifier, importName)) {
            // we have a direct token import, record it and move on.
            recordImport(context, alias, nameOrAliasNode);
        } else if (_tsmorph.ts.isExternalModuleNameRelative(context.moduleSpecifier)) {
            // We know it's not a direct token reference but it's a relative import, so it could contain
            // token references and we need to do further processing.
            const exportInfo = (0, _reexportResolver.resolveExport)(context.importedFile, importName, typeChecker, project);
            if (exportInfo) {
                recordImport(context, alias, nameOrAliasNode, exportInfo);
            // addTemplateGroups(context.importedValues.get(alias)!);
            }
        }
    });
}
/**
 * Process default import using TypeScript's type checker
 */ function processDefaultImport(context) {
    const { importDecl, typeChecker, project } = context;
    const defaultImport = importDecl.getDefaultImport();
    if (!defaultImport) {
        (0, _debugUtils.log)(`No default import found in ${importDecl.getModuleSpecifierValue()}`);
        return;
    }
    const importName = defaultImport.getText();
    if ((0, _tokenUtils.isKnownTokenPackage)(context.moduleSpecifier)) {
        recordImport(context, importName, importDecl);
    } else {
        const exportInfo = (0, _reexportResolver.resolveExport)(context.importedFile, 'default', typeChecker, project);
        if (exportInfo) {
            recordImport(context, importName, defaultImport, exportInfo);
        }
    }
}
function processNamespaceImport(context) {
    const { importDecl, moduleSpecifier, importedFile, importedValues } = context;
    const namespaceImport = importDecl.getNamespaceImport();
    if (!namespaceImport) {
        (0, _debugUtils.log)(`No namespace import found in ${importDecl.getModuleSpecifierValue()}`);
        return;
    }
    const importName = namespaceImport.getText();
    // Only record namespace import if it's the tokens package
    if ((0, _tokenUtils.isKnownTokenPackage)(moduleSpecifier)) {
        importedValues.set(importName, {
            value: importName,
            node: namespaceImport,
            sourceFile: importedFile.getFilePath()
        });
    }
}
// Helper to record an import consistently
function recordImport(ctx, alias, node, exportInfo) {
    const { importedValues, importedFile } = ctx;
    var _exportInfo_sourceFile;
    // Only record known token imports
    const source = (_exportInfo_sourceFile = exportInfo == null ? void 0 : exportInfo.sourceFile) != null ? _exportInfo_sourceFile : importedFile;
    var _exportInfo_valueDeclarationValue;
    // Use actual token literal when available
    const importValue = (_exportInfo_valueDeclarationValue = exportInfo == null ? void 0 : exportInfo.valueDeclarationValue) != null ? _exportInfo_valueDeclarationValue : alias;
    importedValues.set(alias, {
        value: importValue,
        node,
        sourceFile: source.getFilePath(),
        declaredValue: exportInfo == null ? void 0 : exportInfo.valueDeclarationValue,
        declarationNode: exportInfo == null ? void 0 : exportInfo.declaration,
        templateGroups: exportInfo == null ? void 0 : exportInfo.templateGroups
    });
    (0, _debugUtils.log)(`Recorded token import: ${alias} from ${source.getFilePath()}`);
}

//# sourceMappingURL=importAnalyzer.js.map