// tokenUtils.ts
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    addTokenToArray: function() {
        return addTokenToArray;
    },
    extractTokensFromText: function() {
        return extractTokensFromText;
    },
    getInitializerFromIdentifier: function() {
        return getInitializerFromIdentifier;
    },
    getPropertiesForShorthand: function() {
        return getPropertiesForShorthand;
    },
    isKnownTokenPackage: function() {
        return isKnownTokenPackage;
    },
    isTokenReference: function() {
        return isTokenReference;
    },
    isTokenReferenceOld: function() {
        return isTokenReferenceOld;
    }
});
const _tsmorph = require("ts-morph");
const _types = require("./types.js");
const _react = require("@griffel/react");
function isTokenReference(info) {
    const { node, importedValues, project } = info;
    let calledSymbol;
    let calledNodeName = node.getText();
    let importedSymbol;
    const checker = project.getTypeChecker();
    if (_tsmorph.Node.isPropertyAccessExpression(node)) {
        const expression = node.getExpression();
        calledNodeName = expression.getText();
        calledSymbol = checker.getSymbolAtLocation(expression);
    } else {
        calledSymbol = checker.getSymbolAtLocation(node);
    }
    const knownTokenValue = importedValues.get(calledNodeName);
    if (knownTokenValue) {
        const knownTokenNode = knownTokenValue.node;
        importedSymbol = checker.getSymbolAtLocation(knownTokenNode);
        if (importedSymbol === undefined && _tsmorph.Node.isImportSpecifier(knownTokenNode)) {
            importedSymbol = checker.getSymbolAtLocation(knownTokenNode.getNameNode());
        }
    }
    // If we have a known token that is equal to an imported value and both resolve we know it's a token
    return calledSymbol !== undefined && importedSymbol !== undefined && calledSymbol === importedSymbol;
}
function isTokenReferenceOld(textOrNode) {
    // If we have a Node or Symbol, extract the text to check
    let text;
    if (typeof textOrNode === 'string') {
        text = textOrNode;
    } else if (_tsmorph.Node.isNode(textOrNode)) {
        text = textOrNode.getText();
    } else if (textOrNode instanceof _tsmorph.Symbol) {
        // For symbols, we need to check the declarations
        const declarations = textOrNode.getDeclarations();
        if (!declarations || declarations.length === 0) {
            return false;
        }
        // Get text from the first declaration
        text = declarations[0].getText();
    } else {
        return false;
    }
    // IMPORTANT: Reset lastIndex to prevent issues with the global flag
    _types.TOKEN_REGEX.lastIndex = 0;
    const test = _types.TOKEN_REGEX.test(text);
    return test;
}
function getInitializerFromIdentifier(node) {
    const nodeSymbol = node.getSymbol();
    const nodeDeclarations = nodeSymbol == null ? void 0 : nodeSymbol.getDeclarations();
    if (nodeSymbol && nodeDeclarations && nodeDeclarations.length > 0) {
        if (_tsmorph.Node.isVariableDeclaration(nodeDeclarations[0])) {
            const nodeInitializer = nodeDeclarations[0].getInitializer();
            if (nodeInitializer) {
                return nodeInitializer;
            }
        }
    }
}
function extractTokensFromText(textOrNode) {
    // If we have a Node or Symbol, extract the text to check
    let text;
    const matches = [];
    if (typeof textOrNode === 'string') {
        text = textOrNode;
    } else if (_tsmorph.Node.isNode(textOrNode) && _tsmorph.Node.isTemplateExpression(textOrNode)) {
        textOrNode.getTemplateSpans().forEach((span)=>{
            if (isTokenReferenceOld(span.getExpression().getText())) {
                const token = span.getExpression().getText();
                matches.push(token);
            } else {
                const spanExpression = span.getExpression();
                if (spanExpression.getKind() === _tsmorph.SyntaxKind.Identifier) {
                    const spanInitializer = getInitializerFromIdentifier(spanExpression);
                    if (spanInitializer) {
                        matches.push(...extractTokensFromText(spanInitializer));
                    }
                }
            }
        });
    } else if (_tsmorph.Node.isNode(textOrNode)) {
        // If we have an identifier, we need to check if it has an initializer. From there we should reprocess to extract tokens
        if (_tsmorph.Node.isIdentifier(textOrNode)) {
            const initializer = getInitializerFromIdentifier(textOrNode);
            if (initializer) {
                matches.push(...extractTokensFromText(initializer));
            }
        } else {
            text = textOrNode.getText();
        }
    } else {
        // For symbols, we need to check the declarations
        const declarations = textOrNode.getDeclarations();
        if (!declarations || declarations.length === 0) {
            return [];
        }
        // Get text from the first declaration
        text = declarations[0].getText();
    }
    if (text !== undefined) {
        const regMatch = text.match(_types.TOKEN_REGEX);
        if (regMatch) {
            matches.push(...regMatch);
        }
    }
    return matches;
}
function getPropertiesForShorthand(functionName, args) {
    // Extract base function name if it's a qualified name (e.g., shorthands.borderColor -> borderColor)
    const baseName = functionName.includes('.') ? functionName.split('.').pop() : functionName;
    const cleanFunctionName = baseName;
    const shorthandFunction = _react.shorthands[cleanFunctionName];
    if (shorthandFunction) {
        const argValues = args.map(// We have to extract the token from the argument in the case that there's a template literal, initializer, etc.
        (arg)=>extractTokensFromText(arg)[0]);
        // @ts-expect-error We have a very complex union type that is difficult/impossible to resolve statically.
        const shortHandOutput = shorthandFunction(...argValues);
        // Once we have the shorthand output, we should process the values, sanitize them and then return only the properties
        // that contain tokens.
        const shortHandTokens = [];
        Object.keys(shortHandOutput).forEach((key)=>{
            const value = shortHandOutput[key];
            if (isTokenReferenceOld(value)) {
                shortHandTokens.push({
                    property: key,
                    token: value
                });
            }
        });
        return shortHandTokens;
    }
    // The function didn't match any known shorthand functions so return an empty array.
    return [];
}
const addTokenToArray = (tokensToAdd, target, sourceFile)=>{
    // create new array without modifying the original array
    const newArray = target.slice();
    // add items to the array
    if (Array.isArray(tokensToAdd)) {
        newArray.push(...tokensToAdd.map((token)=>({
                ...token,
                ...sourceFile && {
                    sourceFile
                }
            })));
    } else {
        newArray.push({
            ...tokensToAdd,
            ...sourceFile && {
                sourceFile
            }
        });
    }
    // return array without modifying the original array
    return newArray;
};
function isKnownTokenPackage(moduleSpecifier, valueName) {
    const keys = Object.keys(_types.knownTokenImportsAndModules);
    return valueName && keys.includes(valueName) && _types.knownTokenImportsAndModules[valueName].includes(moduleSpecifier) || _types.knownTokenImportsAndModules.default.includes(moduleSpecifier);
}

//# sourceMappingURL=tokenUtils.js.map