"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    findStyleFiles: function() {
        return findStyleFiles;
    },
    resolveImportPath: function() {
        return resolveImportPath;
    }
});
const _fs = require("fs");
const _path = require("path");
const _types = require("./types.js");
async function findStyleFiles(dir) {
    const styleFiles = [];
    async function scan(directory) {
        const entries = await _fs.promises.readdir(directory, {
            withFileTypes: true
        });
        const scanPromises = entries.map(async (entry)=>{
            const fullPath = (0, _path.join)(directory, entry.name);
            if (entry.isDirectory() && !_types.IGNORED_DIRS.includes(entry.name)) {
                await scan(fullPath);
            } else if ((entry.name.includes('style') || entry.name.includes('styles')) && _types.VALID_EXTENSIONS.some((ext)=>entry.name.endsWith(ext))) {
                styleFiles.push(fullPath);
            }
        });
        await Promise.all(scanPromises);
    }
    await scan(dir);
    return styleFiles;
}
async function resolveImportPath(importPath, currentFilePath) {
    if (!importPath.startsWith('.')) {
        return null;
    }
    const dir = (0, _path.dirname)(currentFilePath);
    const absolutePath = (0, _path.resolve)(dir, importPath);
    // Try original path
    try {
        const stats = await _fs.promises.stat(absolutePath);
        if (stats.isFile()) {
            return absolutePath;
        }
    } catch  {
    // Ignore errors and try extensions
    }
    // Try with extensions
    for (const ext of _types.VALID_EXTENSIONS){
        const pathWithExt = absolutePath + ext;
        try {
            const stats = await _fs.promises.stat(pathWithExt);
            if (stats.isFile()) {
                return pathWithExt;
            }
        } catch  {
        // Ignore errors and continue trying
        }
    }
    return null;
}

//# sourceMappingURL=fileOperations.js.map