"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "findTsConfigPath", {
    enumerable: true,
    get: function() {
        return findTsConfigPath;
    }
});
const _interop_require_wildcard = require("@swc/helpers/_/_interop_require_wildcard");
const _path = /*#__PURE__*/ _interop_require_wildcard._(require("path"));
const _fs = /*#__PURE__*/ _interop_require_wildcard._(require("fs"));
function findTsConfigPath(startDir = __dirname) {
    let currentDir = startDir;
    const root = _path.parse(currentDir).root;
    while(currentDir !== root){
        const tsConfigPath = _path.join(currentDir, 'tsconfig.json');
        if (_fs.existsSync(tsConfigPath)) {
            return tsConfigPath;
        }
        // Check if we've hit the file system root dir and bail if we have and haven't found a tsconfig.json
        // This prevents infinite loops in case of misconfigured paths
        if (currentDir === _path.dirname(currentDir)) {
            console.warn(`Hit the root directory looking for tsconfig. Stopping search for tsconfig.json.`);
            return null;
        } else {
            // Move up to parent directory
            currentDir = _path.dirname(currentDir);
        }
    }
    // Check root directory as well
    const rootTsConfigPath = _path.join(root, 'tsconfig.json');
    return _fs.existsSync(rootTsConfigPath) ? rootTsConfigPath : null;
}

//# sourceMappingURL=findTsConfigPath.js.map