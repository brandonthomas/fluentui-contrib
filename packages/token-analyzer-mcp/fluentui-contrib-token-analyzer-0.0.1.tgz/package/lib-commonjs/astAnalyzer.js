"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    analyzeFile: function() {
        return analyzeFile;
    },
    analyzeMakeStyles: function() {
        return analyzeMakeStyles;
    },
    analyzeMergeClasses: function() {
        return analyzeMergeClasses;
    },
    createStyleContent: function() {
        return createStyleContent;
    },
    processStyleProperty: function() {
        return processStyleProperty;
    }
});
const _tsmorph = require("ts-morph");
const _debugUtils = require("./debugUtils.js");
const _importAnalyzer = require("./importAnalyzer.js");
const _tokenResolver = require("./tokenResolver");
const makeResetStylesToken = 'resetStyles';
/**
 * Process a style property to extract token references.
 * Property names are derived from the actual CSS property in the path,
 * not the object key containing them.
 *
 * @param prop The property assignment or spread element to process
 * @param importedValues Map of imported values for resolving token references
 * @param isResetStyles Whether this is a reset styles property
 */ function processStyleProperty(prop, importedValues, project, isResetStyles) {
    let tokens = [];
    const parentName = _tsmorph.Node.isPropertyAssignment(prop) ? prop.getName() : '';
    const path = isResetStyles && parentName ? [
        parentName
    ] : [];
    var _prop_getInitializer;
    // resolve all the tokens within our style recursively. This is encapsulated within the resolveToken function
    tokens = (0, _tokenResolver.resolveToken)({
        node: _tsmorph.Node.isPropertyAssignment(prop) ? (_prop_getInitializer = prop.getInitializer()) != null ? _prop_getInitializer : prop : prop,
        path,
        parentName,
        tokens,
        importedValues,
        project
    });
    return tokens;
}
/**
 * Analyzes mergeClasses calls to determine style relationships
 */ function analyzeMergeClasses(sourceFile) {
    const mappings = [];
    sourceFile.forEachDescendant((node)=>{
        if (_tsmorph.Node.isCallExpression(node) && node.getExpression().getText() === 'mergeClasses') {
            const parentNode = node.getParent();
            let slotName = '';
            if (_tsmorph.Node.isBinaryExpression(parentNode)) {
                slotName = parentNode.getLeft().getText().split('.')[1];
            }
            const mapping = {
                baseStyles: [],
                conditionalStyles: [],
                slotName
            };
            /**
       *  TODO: We could also walk the tree to find what function is assigned to our makeStyles call, and thus, what
       * styles object we're working with. Typically this is called `useStyles` and then assigned to `styles`. We've hard
       * coded it for now but this could be improved.
       */ node.getArguments().forEach((arg)=>{
                // Handle direct style references
                if (_tsmorph.Node.isPropertyAccessExpression(arg)) {
                    mapping.baseStyles.push(arg.getText());
                } else if (_tsmorph.Node.isBinaryExpression(arg)) {
                    const right = arg.getRight();
                    if (_tsmorph.Node.isPropertyAccessExpression(right)) {
                        mapping.conditionalStyles.push({
                            style: right.getText(),
                            condition: arg.getLeft().getText()
                        });
                    }
                } else if (!arg.getText().includes('.')) {
                    // We found a single variable (makeResetStyles or other assignment), add to base styles for lookup later
                    mapping.baseStyles.push(arg.getText());
                }
            });
            if (mapping.baseStyles.length || mapping.conditionalStyles.length) {
                mappings.push(mapping);
            }
        }
    });
    return mappings;
}
/**
 * Creates a StyleContent object from token references.
 *
 * The path structure in token references is relative to the style property being processed.
 * For example, given a style object:
 * ```typescript
 * {
 *   root: {              // Handled by analyzeMakeStyles
 *     color: token,      // path = ['color']
 *     ':hover': {        // Start of nested structure
 *       color: token     // path = [':hover', 'color']
 *     }
 *   }
 * }
 * ```
 * Property names reflect the actual CSS property, derived from the path.
 */ function createStyleContent(tokens) {
    const content = {
        tokens: tokens.filter((t)=>{
            return t.path.length === 1;
        })
    };
    // Nested structures have paths longer than 1
    const nestedTokens = tokens.filter((t)=>t.path.length > 1);
    if (nestedTokens.length > 0) {
        const acc = {};
        /**
     * Recursive function to create a nested structure for tokens
     * This function will create a nested object structure based on the token path.
     * @param token
     * @param pathIndex where in the path we are, this allows us to preserve the path while recursing through it
     * @param currentLevel the current level of the nested structure we're working on
     */ const createNestedStructure = (token, pathIndex, currentLevel)=>{
            const nestedKey = token.path[pathIndex];
            // if no token array exists, create one
            if (!currentLevel[nestedKey]) {
                currentLevel[nestedKey] = {
                    tokens: []
                };
            }
            // if we have a path length that is greater than our current index minus 1, we need to recurse
            // this is because if we have more than a single item in our path left there's another level
            if (token.path.length - 1 - pathIndex > 1) {
                // Create a nested structure through a recursive call
                let cuurrentLevel = currentLevel[nestedKey].nested;
                if (!cuurrentLevel) {
                    cuurrentLevel = {};
                }
                currentLevel[nestedKey].nested = cuurrentLevel;
                createNestedStructure(token, pathIndex + 1, cuurrentLevel);
            } else {
                currentLevel[nestedKey].tokens.push({
                    ...token,
                    path: token.path
                });
            }
        };
        nestedTokens.forEach((token)=>{
            createNestedStructure(token, 0, acc);
        });
        content.nested = acc;
    }
    return content;
}
/**
 * Creates metadata from style mappings
 */ function createMetadata(styleMappings) {
    const metadata = {
        styleConditions: {}
    };
    styleMappings.forEach((mapping)=>{
        mapping.baseStyles.forEach((style)=>{
            if (metadata.styleConditions[style]) {
                metadata.styleConditions[style].isBase = true;
            } else {
                metadata.styleConditions[style] = {
                    isBase: true,
                    slotName: mapping.slotName || ''
                };
            }
        });
        mapping.conditionalStyles.forEach(({ style, condition })=>{
            if (metadata.styleConditions[style]) {
                metadata.styleConditions[style].conditions = metadata.styleConditions[style].conditions || [];
                if (condition) {
                    metadata.styleConditions[style].conditions.push(condition);
                }
            } else {
                metadata.styleConditions[style] = {
                    conditions: condition ? [
                        condition
                    ] : [],
                    slotName: mapping.slotName || ''
                };
            }
        });
    });
    return metadata;
}
/**
 * Analyzes makeStyles calls to get token usage and structure
 */ async function analyzeMakeStyles(sourceFile, importedValues, project) {
    const analysis = {};
    sourceFile.forEachDescendant((node)=>{
        if (_tsmorph.Node.isCallExpression(node) && node.getExpression().getText() === 'makeStyles') {
            const stylesArg = node.getArguments()[0];
            const parentNode = node.getParent();
            if (_tsmorph.Node.isObjectLiteralExpression(stylesArg) && _tsmorph.Node.isVariableDeclaration(parentNode)) {
                // Process the styles object
                stylesArg.getProperties().forEach((prop)=>{
                    if (_tsmorph.Node.isPropertyAssignment(prop)) {
                        const styleName = prop.getName();
                        const tokens = processStyleProperty(prop, importedValues, project);
                        const functionName = parentNode.getName();
                        if (!analysis[functionName]) {
                            analysis[functionName] = {};
                        }
                        if (tokens.length) {
                            analysis[functionName][styleName] = createStyleContent(tokens);
                        }
                    }
                });
            }
        } else if (_tsmorph.Node.isCallExpression(node) && node.getExpression().getText() === 'makeResetStyles') {
            // Similar to above, but the styles are stored under the assigned function name instead of local variable
            const stylesArg = node.getArguments()[0];
            const parentNode = node.getParent();
            if (_tsmorph.Node.isVariableDeclaration(parentNode)) {
                const functionName = parentNode.getName();
                if (!analysis[functionName]) {
                    analysis[functionName] = {};
                }
                // We store 'isResetStyles' to differentiate from makeStyles and link mergeClasses variables
                analysis[functionName][makeResetStylesToken] = {
                    tokens: [],
                    nested: {},
                    isResetStyles: true
                };
                if (_tsmorph.Node.isObjectLiteralExpression(stylesArg)) {
                    // Process the styles object
                    stylesArg.getProperties().forEach((prop)=>{
                        if (_tsmorph.Node.isPropertyAssignment(prop) || _tsmorph.Node.isSpreadAssignment(prop)) {
                            const tokens = processStyleProperty(prop, importedValues, project, true);
                            if (tokens.length) {
                                const styleContent = createStyleContent(tokens);
                                analysis[functionName][makeResetStylesToken].tokens = analysis[functionName][makeResetStylesToken].tokens.concat(styleContent.tokens);
                                analysis[functionName][makeResetStylesToken].nested = {
                                    ...analysis[functionName][makeResetStylesToken].nested,
                                    ...styleContent.nested
                                };
                            }
                        }
                    });
                }
            }
        }
    });
    const variables = [];
    const styleFunctionNames = Object.keys(analysis);
    sourceFile.forEachDescendant((node)=>{
        // We do a second parse to link known style functions (i.e. makeResetStyles  assigned function variable names).
        // This is necessary to handle cases where we're using a variable directly in mergeClasses to link styles.
        if (_tsmorph.Node.isCallExpression(node) && styleFunctionNames.includes(node.getExpression().getText())) {
            const parentNode = node.getParent();
            const functionName = node.getExpression().getText();
            if (_tsmorph.Node.isVariableDeclaration(parentNode)) {
                const variableName = parentNode.getName();
                const variableMap = {
                    functionName,
                    variableName
                };
                variables.push(variableMap);
            }
        }
    });
    // Store our makeResetStyles assigned variables in the analysis to link later
    variables.forEach((variable)=>{
        Object.keys(analysis[variable.functionName]).forEach((styleName)=>{
            var _analysis_variable_functionName_styleName_assignedVariables;
            if (analysis[variable.functionName][styleName].assignedVariables === undefined) {
                analysis[variable.functionName][styleName].assignedVariables = [];
            }
            (_analysis_variable_functionName_styleName_assignedVariables = analysis[variable.functionName][styleName].assignedVariables) == null ? void 0 : _analysis_variable_functionName_styleName_assignedVariables.push(variable.variableName);
        });
    });
    return analysis;
}
/**
 * Combines mergeClasses and makeStyles analysis, with import resolution
 */ async function analyzeFile(filePath, project) {
    (0, _debugUtils.log)(`Analyzing ${filePath}`);
    const sourceFile = project.addSourceFileAtPath(filePath);
    // First analyze imports to find imported string values
    (0, _debugUtils.log)('Analyzing imports to find imported token values');
    const importedValues = await (0, _debugUtils.measureAsync)('analyze imports', ()=>(0, _importAnalyzer.analyzeImports)(sourceFile, project));
    // Second pass: Analyze mergeClasses
    const styleMappings = (0, _debugUtils.measure)('analyze mergeClasses', ()=>analyzeMergeClasses(sourceFile));
    // Third pass: Analyze makeStyles with imported values
    const styleAnalysis = await (0, _debugUtils.measureAsync)('analyze makeStyles', ()=>analyzeMakeStyles(sourceFile, importedValues, project));
    // Create enhanced analysis with separated styles and metadata
    return {
        styles: styleAnalysis,
        metadata: createMetadata(styleMappings)
    };
}

//# sourceMappingURL=astAnalyzer.js.map