// moduleResolver.ts
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    clearModuleCache: function() {
        return clearModuleCache;
    },
    getModuleSourceFile: function() {
        return getModuleSourceFile;
    },
    modulePathCache: function() {
        return modulePathCache;
    },
    resolveModulePath: function() {
        return resolveModulePath;
    },
    resolvedFilesCache: function() {
        return resolvedFilesCache;
    },
    tsUtils: function() {
        return tsUtils;
    },
    verifyFileExists: function() {
        return verifyFileExists;
    }
});
const _interop_require_wildcard = require("@swc/helpers/_/_interop_require_wildcard");
const _typescript = /*#__PURE__*/ _interop_require_wildcard._(require("typescript"));
const _path = /*#__PURE__*/ _interop_require_wildcard._(require("path"));
const _fs = /*#__PURE__*/ _interop_require_wildcard._(require("fs"));
const _debugUtils = require("./debugUtils.js");
const tsUtils = {
    resolveModuleName: (moduleName, containingFile, compilerOptions, host)=>_typescript.resolveModuleName(moduleName, containingFile, compilerOptions, host),
    getFileSize: (filePath)=>_typescript.sys.getFileSize == null ? void 0 : _typescript.sys.getFileSize.call(_typescript.sys, filePath),
    fileExists: (filePath)=>_typescript.sys.fileExists(filePath)
};
const modulePathCache = new Map();
const resolvedFilesCache = new Map();
/**
 * Creates a cache key for module resolution
 */ function createCacheKey(moduleSpecifier, containingFile) {
    return `${containingFile}:${moduleSpecifier}`;
}
/**
 * Verifies a resolved file path actually exists
 */ function verifyFileExists(filePath) {
    if (!filePath) {
        return false;
    }
    try {
        // Use TypeScript's file system abstraction for testing compatibility
        return tsUtils.fileExists(filePath);
    } catch (e) {
        // If that fails, try Node's fs as fallback
        (0, _debugUtils.log)(`Error checking file existence with TypeScript: ${filePath}`, e);
        try {
            return _fs.existsSync(filePath);
        } catch (nestedE) {
            (0, _debugUtils.log)(`Error checking file existence: ${filePath}`, nestedE);
            return false;
        }
    }
}
function resolveModulePath(project, moduleSpecifier, containingFile) {
    const cacheKey = createCacheKey(moduleSpecifier, containingFile);
    // Check cache first
    if (modulePathCache.has(cacheKey)) {
        const cachedPath = modulePathCache.get(cacheKey);
        if (cachedPath) {
            return cachedPath;
        }
    }
    // For relative paths, try a simple path resolution first
    if (moduleSpecifier.startsWith('.')) {
        try {
            const basePath = _path.dirname(containingFile);
            const extensions = [
                '.ts',
                '.tsx',
                '.js',
                '.jsx',
                '.d.ts'
            ];
            // Check if the module specifier already has a valid extension
            const hasExtension = extensions.some((ext)=>moduleSpecifier.endsWith(ext));
            // 1. If it has an extension, try the exact path first
            if (hasExtension) {
                const exactPath = _path.resolve(basePath, moduleSpecifier);
                if (verifyFileExists(exactPath)) {
                    modulePathCache.set(cacheKey, exactPath);
                    return exactPath;
                }
            }
            // 2. Try with added extensions (for paths without extension or if exact path failed)
            if (!hasExtension) {
                for (const ext of extensions){
                    const candidatePath = _path.resolve(basePath, moduleSpecifier + ext);
                    if (verifyFileExists(candidatePath)) {
                        modulePathCache.set(cacheKey, candidatePath);
                        return candidatePath;
                    }
                }
            }
            // 3. Try as directory with index file
            const dirPath = hasExtension ? _path.resolve(basePath, _path.dirname(moduleSpecifier), _path.basename(moduleSpecifier, _path.extname(moduleSpecifier))) : _path.resolve(basePath, moduleSpecifier);
            for (const ext of extensions){
                const candidatePath = _path.resolve(dirPath, 'index' + ext);
                if (verifyFileExists(candidatePath)) {
                    modulePathCache.set(cacheKey, candidatePath);
                    return candidatePath;
                }
            }
        } catch (e) {
            // Fall through to TypeScript's module resolution
            (0, _debugUtils.log)(`Error resolving module: ${moduleSpecifier}`, e);
        }
    }
    // Use TypeScript's module resolution API
    const result = tsUtils.resolveModuleName(moduleSpecifier, containingFile, project.getCompilerOptions(), _typescript.sys);
    // Validate and cache the result
    if (result.resolvedModule) {
        const resolvedPath = result.resolvedModule.resolvedFileName;
        // Verify the file actually exists
        if (verifyFileExists(resolvedPath)) {
            modulePathCache.set(cacheKey, resolvedPath);
            return resolvedPath;
        }
    }
    // Cache negative result
    (0, _debugUtils.log)(`Could not resolve module: ${moduleSpecifier} from ${containingFile}`);
    modulePathCache.set(cacheKey, null);
    return null;
}
function getModuleSourceFile(project, moduleSpecifier, containingFile) {
    (0, _debugUtils.log)(`Resolving module: ${moduleSpecifier} from ${containingFile}`);
    // Step 1: Try to resolve the module to a file path
    const resolvedPath = resolveModulePath(project, moduleSpecifier, containingFile);
    if (!resolvedPath) {
        (0, _debugUtils.log)(`Could not resolve module: ${moduleSpecifier}`);
        return null;
    }
    // Step 2: Check if we already have this file
    if (resolvedFilesCache.has(resolvedPath)) {
        const cachedFile = resolvedFilesCache.get(resolvedPath);
        if (cachedFile) {
            return cachedFile;
        }
    }
    // Step 3: Get or add the file to the project
    try {
        // First try to get file if it's already in the project
        let sourceFile = project.getSourceFile(resolvedPath);
        // If not found, add it
        if (!sourceFile) {
            sourceFile = project.addSourceFileAtPath(resolvedPath);
            (0, _debugUtils.log)(`Added source file: ${resolvedPath}`);
        }
        // Cache the result
        resolvedFilesCache.set(resolvedPath, sourceFile);
        return sourceFile;
    } catch (error) {
        (0, _debugUtils.log)(`Error adding source file: ${resolvedPath}`, error);
        return null;
    }
}
function clearModuleCache() {
    modulePathCache.clear();
    resolvedFilesCache.clear();
}

//# sourceMappingURL=moduleResolver.js.map