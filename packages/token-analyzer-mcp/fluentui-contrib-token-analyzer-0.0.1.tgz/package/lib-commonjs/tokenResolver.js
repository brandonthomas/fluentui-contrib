"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "resolveToken", {
    enumerable: true,
    get: function() {
        return resolveToken;
    }
});
const _tsmorph = require("ts-morph");
const _tokenUtils = require("./tokenUtils");
const _processTemplateStringLiteral = require("./processTemplateStringLiteral");
const resolveToken = (info)=>{
    const { node, tokens } = info;
    if (_tsmorph.Node.isStringLiteral(node)) {
        // Path in the event we need to process string literals, however this isn't used given tokens are stored as
        // initialized values and imports. Generally, as property accessors or identifiers
        // For now we'll leave a stub
        return processStringLiteral(info);
    } else if (_tsmorph.Node.isTemplateExpression(node)) {
        return processTemplateExpression(info);
    } else if (_tsmorph.Node.isIdentifier(node)) {
        return processIdentifier(info);
    } else if (_tsmorph.Node.isPropertyAccessExpression(node)) {
        return processPropertyAccess(info);
    } else if (_tsmorph.Node.isObjectLiteralExpression(node)) {
        return processObjectLiteral(info);
    } else if (_tsmorph.Node.isSpreadAssignment(node)) {
        return processSpreadAssignment(info);
    } else if (_tsmorph.Node.isCallExpression(node) && node.getExpression().getText() === 'createCustomFocusIndicatorStyle') {
        return processFocusCallExpression(info);
    } else if (_tsmorph.Node.isCallExpression(node)) {
        return processCallExpression(info);
    } else if (_tsmorph.Node.isPropertyAssignment(node)) {
        return processPropertyAssignment(info);
    }
    return tokens;
};
/**
 * Stub for processing string literals which we don't need currently.
 * @param node
 * @returns
 */ const processStringLiteral = (info)=>{
    return info.tokens;
};
const processIdentifier = (info)=>{
    const { node, parentName, path, tokens, sourceFile, importedValues } = info;
    let returnTokens = tokens.slice();
    const text = node.getText();
    const intializerNode = (0, _tokenUtils.getInitializerFromIdentifier)(node);
    if ((0, _tokenUtils.isTokenReference)(info)) {
        var _path_;
        const propertyName = (_path_ = path[path.length - 1]) != null ? _path_ : parentName;
        const importedVal = importedValues.get(text);
        // our template groups are already processed and we know they are known tokens so we can just add them
        if (importedVal.templateGroups && importedVal.templateGroups.length > 0) {
            importedVal.templateGroups.forEach((group)=>{
                const grouped = {
                    property: propertyName,
                    token: [],
                    path
                };
                group.forEach((exprNode)=>{
                    var _exprNode_actualTokenValue;
                    grouped.token.push((_exprNode_actualTokenValue = exprNode.actualTokenValue) != null ? _exprNode_actualTokenValue : exprNode.node.getText());
                });
                if (grouped.token.length > 0) {
                    returnTokens.push(grouped);
                }
            });
        } else {
            returnTokens = (0, _tokenUtils.addTokenToArray)({
                property: propertyName,
                token: [
                    importedVal.value
                ],
                path
            }, returnTokens, sourceFile);
        }
        return returnTokens;
    } else if (intializerNode) {
        // we have a variable declaration and we should then check if the value is a token as well. Reprocess the node
        returnTokens = returnTokens.concat(resolveToken({
            ...info,
            node: intializerNode
        }));
    }
    return returnTokens;
};
const processPropertyAccess = (info)=>{
    const { node, parentName, path, tokens, sourceFile } = info;
    const text = node.getText();
    const isToken = (0, _tokenUtils.isTokenReference)(info);
    if (isToken) {
        var _path_;
        return (0, _tokenUtils.addTokenToArray)({
            property: (_path_ = path[path.length - 1]) != null ? _path_ : parentName,
            token: [
                text
            ],
            path
        }, tokens, sourceFile);
    }
    return tokens;
};
const processObjectLiteral = (info)=>{
    const { node, tokens } = info;
    let returnTokens = tokens.slice();
    node.getProperties().forEach((childProp)=>{
        returnTokens = returnTokens.concat(resolveToken({
            ...info,
            node: childProp
        }));
    });
    return returnTokens;
};
const processSpreadAssignment = (info)=>{
    const { node, tokens } = info;
    return tokens.concat(resolveToken({
        ...info,
        node: node.getExpression()
    }));
};
const processFocusCallExpression = (info)=>{
    const { node, path, parentName, tokens, importedValues } = info;
    const focus = `:focus`;
    const focusWithin = `:focus-within`;
    let nestedModifier = focus;
    const passedTokens = node.getArguments()[0];
    const passedOptions = node.getArguments()[1];
    // Parse out the options being passed to the focus funuction and determine which selector is being used
    if (passedOptions && _tsmorph.Node.isObjectLiteralExpression(passedOptions)) {
        passedOptions.getProperties().forEach((property)=>{
            if (_tsmorph.Node.isPropertyAssignment(property)) {
                const optionName = property.getName();
                if (optionName === 'selector') {
                    var _property_getInitializer;
                    const selectorType = (_property_getInitializer = property.getInitializer()) == null ? void 0 : _property_getInitializer.getText();
                    if (selectorType === 'focus') {
                        nestedModifier = focus;
                    } else if (selectorType === 'focus-within') {
                        nestedModifier = focusWithin;
                    }
                }
            }
        });
    }
    if (passedTokens) {
        // We can simplify the logic since we process node types and extract within resolveTokens. We merely need to pass
        // the updated path
        return resolveToken({
            ...info,
            node: passedTokens,
            path: [
                ...path,
                nestedModifier
            ],
            parentName,
            tokens,
            importedValues
        });
    }
    return tokens;
};
const processCallExpression = (info)=>{
    const { node, path, tokens, importedValues, sourceFile } = info;
    let returnTokens = tokens.slice();
    // Process calls like shorthands.borderColor(tokens.color)
    const functionName = node.getExpression().getText();
    // check if we're using a shorthand function and get the output of a call based on parameters passed into the function
    const affectedProperties = (0, _tokenUtils.getPropertiesForShorthand)(functionName, node.getArguments());
    // If we have a shorthand function, we need to process the affected properties.
    // getPropertiesForShorthand will return an array of objects
    // with the property name and the token reference
    // e.g. { property: 'borderColor', token: 'tokens.color' }
    // It will also deeply check for initialized values etc and validate they are tokens
    if (affectedProperties.length > 0) {
        // Process each argument and apply it to all affected properties
        affectedProperties.forEach((argument)=>{
            returnTokens = (0, _tokenUtils.addTokenToArray)({
                property: argument.property,
                token: [
                    argument.token
                ],
                path: path.concat(argument.property)
            }, returnTokens, sourceFile);
        });
    } else {
        // Generic handling of functions that are not whitelisted
        node.getArguments().forEach((argument)=>{
            returnTokens = returnTokens.concat(resolveToken({
                ...info,
                node: argument,
                path: [
                    ...path,
                    functionName
                ],
                tokens: returnTokens,
                importedValues
            }));
        });
    }
    return returnTokens;
};
/**
 * This is where we process template spans and feed it back into resolveToken. We also need to check that
 * imported values are tokens etc.
 * We also break down each individual group of fallbacks as multiple tokens in our output. So if a single property
 * like shadow has a few var() functions, we should return each one as a separate token. We should do the same with
 * separate token values in general.
 * @param info
 * @returns
 */ const processTemplateExpression = (info)=>{
    const { node, path, parentName, tokens } = info;
    const returnTokens = tokens.slice();
    for (const expressions of (0, _processTemplateStringLiteral.extractNodesFromTemplateStringLiteral)(node).extractedExpressions){
        var _path_;
        // We should create a new token entry if we do indeed have tokens within our literal at this stage
        const groupedTokens = {
            property: (_path_ = path[path.length - 1]) != null ? _path_ : parentName,
            token: [],
            path
        };
        for (const nestedExpression of expressions){
            const processedToken = resolveToken({
                ...info,
                tokens: [],
                node: nestedExpression
            });
            if (processedToken.length > 0) {
                for (const token of processedToken){
                    groupedTokens.token.push(...token.token);
                }
            }
        }
        // If we have verified tokens (at least one), push them to the tokens array
        // If this is empty, we only had expressions but no tokens.
        if (groupedTokens.token.length > 0) {
            returnTokens.push(groupedTokens);
        }
    }
    return returnTokens;
};
const processPropertyAssignment = (info)=>{
    const { node, path } = info;
    const childName = node.getName();
    const newPath = [
        ...path,
        childName
    ];
    const propertyNode = node.getInitializer();
    return resolveToken({
        ...info,
        node: propertyNode != null ? propertyNode : node,
        path: newPath
    });
};

//# sourceMappingURL=tokenResolver.js.map