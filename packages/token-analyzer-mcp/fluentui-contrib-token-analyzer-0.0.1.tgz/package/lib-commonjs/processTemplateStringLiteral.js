"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "extractNodesFromTemplateStringLiteral", {
    enumerable: true,
    get: function() {
        return extractNodesFromTemplateStringLiteral;
    }
});
const extractNodesFromTemplateStringLiteral = (expression)=>{
    const extractedExpressions = [];
    const spans = expression.getTemplateSpans();
    // Track the state as we process each part of the template
    let currentGroup = [];
    let inVar = false;
    let nestingLevel = 0;
    // Process the template head
    const head = expression.getHead().getText();
    processText(head);
    // Process each span and its literal
    spans.forEach((span)=>{
        // Process the expression
        const expr = span.getExpression();
        if (inVar) {
            // If inside var(), add to current group
            currentGroup.push(expr);
        } else {
            // If not inside var(), create a standalone group for this expression
            extractedExpressions.push([
                expr
            ]);
        }
        // Process the literal text after this expression
        const literal = span.getLiteral().getText();
        processText(literal);
    });
    // Helper function to process text parts
    function processText(text) {
        for(let i = 0; i < text.length; i++){
            // Check for start of var() - no whitespace allowed
            if (i + 3 < text.length && text.substring(i, i + 4) === 'var(' && (nestingLevel === 0 || inVar)) {
                if (nestingLevel === 0) {
                    inVar = true;
                    // If we already have a group, add it to our results
                    if (currentGroup.length > 0) {
                        extractedExpressions.push([
                            ...currentGroup
                        ]);
                        currentGroup = [];
                    }
                }
                nestingLevel++;
                i += 3; // Skip to the opening parenthesis
            } else if (text[i] === '(' && inVar) {
                nestingLevel++;
            } else if (text[i] === ')' && inVar) {
                nestingLevel--;
                if (nestingLevel === 0) {
                    inVar = false;
                    // If we've closed a var() and have a group, add it
                    if (currentGroup.length > 0) {
                        extractedExpressions.push([
                            ...currentGroup
                        ]);
                        currentGroup = [];
                    }
                }
            }
        }
    }
    // Handle any remaining nodes in the current group
    if (currentGroup.length > 0) {
        extractedExpressions.push(currentGroup);
    }
    return {
        originalExpression: expression,
        extractedExpressions
    };
};

//# sourceMappingURL=processTemplateStringLiteral.js.map