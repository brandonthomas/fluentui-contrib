#!/usr/bin/env node
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "analyzeProjectStyles", {
    enumerable: true,
    get: function() {
        return analyzeProjectStyles;
    }
});
const _interop_require_default = require("@swc/helpers/_/_interop_require_default");
const _tsmorph = require("ts-morph");
const _fs = require("fs");
const _path = require("path");
const _prettier = require("prettier");
const _fileOperations = require("./fileOperations.js");
const _astAnalyzer = require("./astAnalyzer.js");
const _debugUtils = require("./debugUtils.js");
const _findTsConfigPath = require("./findTsConfigPath.js");
const _helpers = require("yargs/helpers");
const _yargs = /*#__PURE__*/ _interop_require_default._(require("yargs/yargs"));
async function analyzeProjectStyles(rootDir, outputFile, options = {}) {
    (0, _debugUtils.configure)({
        debug: options.debug || false,
        perf: options.perf || false
    });
    (0, _debugUtils.log)(`Starting analysis of ${rootDir}`);
    const results = {};
    try {
        const styleFiles = await (0, _debugUtils.measureAsync)('find style files', ()=>(0, _fileOperations.findStyleFiles)(rootDir));
        console.log(`Found ${styleFiles.length} style files to analyze`);
        var _findTsConfigPath1;
        const project = new _tsmorph.Project({
            // Get the nearest tsconfig.json file so we can resolve modules and paths correctly based on the project config
            tsConfigFilePath: (_findTsConfigPath1 = (0, _findTsConfigPath.findTsConfigPath)(rootDir)) != null ? _findTsConfigPath1 : undefined,
            skipAddingFilesFromTsConfig: true,
            skipFileDependencyResolution: false
        });
        for (const file of styleFiles){
            const relativePath = (0, _path.relative)(rootDir, file);
            console.log(`Analyzing ${relativePath}...`);
            try {
                const analysis = await (0, _astAnalyzer.analyzeFile)(file, project);
                if (Object.keys(analysis.styles).length > 0) {
                    results[relativePath] = {
                        styles: analysis.styles,
                        metadata: analysis.metadata
                    };
                }
            } catch (err) {
                (0, _debugUtils.error)(`Error analyzing ${relativePath}:`, err);
            }
        }
        if (outputFile) {
            await (0, _debugUtils.measureAsync)('write output file', async ()=>{
                const formatted = (0, _prettier.format)(JSON.stringify(sortObjectByKeys(results), null, 2), {
                    parser: 'json',
                    printWidth: 120,
                    tabWidth: 2,
                    singleQuote: true,
                    trailingComma: 'all',
                    arrowParens: 'avoid'
                });
                await _fs.promises.writeFile(outputFile, formatted, 'utf8');
                console.log(`Analysis written to ${outputFile}`);
            });
        }
        return results;
    } catch (err) {
        (0, _debugUtils.error)('Error during analysis:', err);
        throw err;
    }
}
/**
 * Sorts an object by its keys alphabetically
 *
 * @param obj Object to sort
 * @returns New object with the same properties, sorted by keys
 */ function sortObjectByKeys(obj) {
    return Object.keys(obj).sort().reduce((sorted, key)=>{
        sorted[key] = obj[key];
        return sorted;
    }, {});
}
function countTokens(analysis) {
    let count = 0;
    Object.values(analysis.styles).forEach((_value)=>{
        Object.values(_value).forEach((value)=>{
            count += value.tokens.length;
            if (value.nested) {
                Object.values(value.nested).forEach((nestedValue)=>{
                    count += nestedValue.tokens.length;
                });
            }
        });
    });
    return count;
}
// CLI execution
const isRunningDirectly = require.main === module || // Standard Node.js detection
process.argv[1].includes('token-analyzer') || // When run as global CLI
process.argv[1].endsWith('index.js') || // When run directly
process.argv[1].includes('index'); // Your original check
if (isRunningDirectly) {
    const argv = (0, _yargs.default)((0, _helpers.hideBin)(process.argv)).usage('$0 [options]', 'Analyze project styles and token usage').option('root', {
        alias: 'r',
        describe: 'Root directory to analyze',
        type: 'string',
        default: '.'
    }).option('output', {
        alias: 'o',
        describe: 'Output file path',
        type: 'string',
        default: './token-analysis.json'
    }).option('debug', {
        alias: 'd',
        describe: 'Enable debug mode',
        type: 'boolean',
        default: false
    }).option('perf', {
        alias: 'p',
        describe: 'Enable performance tracking',
        type: 'boolean',
        default: false
    }).example('$0', 'Run with default settings').example('$0 --root ./components --output ./results.json', 'Analyze components directory').example('$0 -r ./src -o ./analysis.json --debug', 'Run with debug mode').help('h').alias('h', 'help').version().strict().parseSync();
    const { root: rootDir, output: outputFile, debug, perf } = argv;
    console.log(`Starting analysis of ${rootDir}`);
    console.log(`Output will be written to ${outputFile}`);
    if (debug) console.log('Debug mode enabled');
    if (perf) console.log('Performance tracking enabled');
    analyzeProjectStyles(rootDir, outputFile, {
        debug,
        perf
    }).then((results)=>{
        const totalFiles = Object.keys(results).length;
        let totalTokens = 0;
        Object.values(results).forEach((fileAnalysis)=>{
            totalTokens += countTokens(fileAnalysis);
        });
        console.log('\nAnalysis complete!');
        console.log(`Processed ${totalFiles} files containing styles`);
        console.log(`Found ${totalTokens} token references`);
    }).catch((err)=>{
        console.error('Analysis failed:', err);
        process.exit(1);
    });
}

//# sourceMappingURL=index.js.map