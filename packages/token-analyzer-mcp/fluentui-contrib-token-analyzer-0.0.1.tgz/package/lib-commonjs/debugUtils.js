"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    configure: function() {
        return configure;
    },
    error: function() {
        return error;
    },
    log: function() {
        return log;
    },
    measure: function() {
        return measure;
    },
    measureAsync: function() {
        return measureAsync;
    }
});
const _perf_hooks = require("perf_hooks");
let config = {
    debug: false,
    perf: false
};
const configure = (options)=>{
    config = {
        ...config,
        ...options
    };
};
const log = (message, ...args)=>{
    if (config.debug) {
        console.log(`DEBUG: ${message}`, ...args);
    }
};
const error = (message, errorArg)=>{
    // Always log errors, but with debug info if enabled
    const prefix = config.debug ? 'DEBUG ERROR: ' : 'ERROR: ';
    console.error(`${prefix}${message}`, errorArg);
};
const measureAsync = async (name, fn)=>{
    if (!config.perf) {
        return fn();
    }
    const start = _perf_hooks.performance.now();
    return fn().finally(()=>{
        const end = _perf_hooks.performance.now();
        console.log(`PERF: ${name} took ${(end - start).toFixed(2)}ms`);
    });
};
const measure = (name, fn)=>{
    if (!config.perf) {
        return fn();
    }
    const start = _perf_hooks.performance.now();
    const result = fn();
    const end = _perf_hooks.performance.now();
    console.log(`PERF: ${name} took ${(end - start).toFixed(2)}ms`);
    return result;
};

//# sourceMappingURL=debugUtils.js.map